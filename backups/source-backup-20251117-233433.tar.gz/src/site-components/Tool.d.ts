import * as React from "react";

declare function Tool(
    props: {
        as?: React.ElementType;
    }
): React.JSX.Element