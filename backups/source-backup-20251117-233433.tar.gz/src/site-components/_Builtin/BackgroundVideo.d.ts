export declare const BackgroundVideoWrapper: any;
export declare const BackgroundVideoPlayPauseButton: any;
export declare const BackgroundVideoPlayPauseButtonPlaying: any;
export declare const BackgroundVideoPlayPauseButtonPaused: any;
