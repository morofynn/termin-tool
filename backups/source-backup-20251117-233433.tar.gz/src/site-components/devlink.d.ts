export declare function createIX2Engine(): any;
declare const _default: {
    createIX2Engine: typeof createIX2Engine;
};
export default _default;
