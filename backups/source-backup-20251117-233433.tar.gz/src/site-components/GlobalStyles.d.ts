import * as React from "react";

declare function GlobalStyles(
    props: {
        as?: React.ElementType;
    }
): React.JSX.Element