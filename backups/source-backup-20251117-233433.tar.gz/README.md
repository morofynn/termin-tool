# 📅 MORO Terminbuchungssystem

Professionelles Terminbuchungssystem für Events mit Google Calendar Integration und automatischen E-Mail-Benachrichtigungen.

## ✨ Features

- ✅ **3-Tages-Event Support** (Freitag-Sonntag)
- ✅ **Google Calendar Integration** mit OAuth 2.0
- ✅ **E-Mail-Benachrichtigungen** via Gmail API
- ✅ **Admin Panel** mit vollständiger Terminverwaltung
- ✅ **Audit Log** für alle Systemaktionen
- ✅ **Wartungsmodus** & Rate Limiting
- ✅ **Mobile-optimiert** mit Touch-Support
- ✅ **ICS-Kalenderanhänge** in E-Mails

## 🚀 Schnellstart

### 1. Google Setup
1. Google Cloud Console öffnen
2. Calendar API + Gmail API aktivieren
3. OAuth Client erstellen (Web Application)
4. Credentials notieren

### 2. Environment Variables
In Webflow unter **App Settings**:
```bash
GOOGLE_CLIENT_ID=...
GOOGLE_CLIENT_SECRET=...
GOOGLE_REDIRECT_URI=https://your-domain.com/api/auth/google-callback
GOOGLE_USER_EMAIL=your-email@gmail.com
ADMIN_PASSWORD=your-secure-password
```

### 3. Google Calendar autorisieren
1. Admin Panel öffnen: `/secure-admin-panel-xyz789`
2. Settings → Google Calendar verbinden
3. Google Account auswählen und Zugriff erlauben

✅ **Fertig!**

## 📖 Dokumentation

- **[Setup Guide](docs/SETUP.md)** - Vollständige Einrichtungsanleitung
- **[API Documentation](docs/API.md)** - API Endpunkte & Beispiele
- **[Changelog](docs/CHANGELOG.md)** - Versionshistorie
- **[Architecture](docs/ARCHITECTURE.md)** - Technische Details

## 🛠️ Tech Stack

- **Astro 5** + React 19
- **Tailwind CSS 4** + shadcn/ui
- **Cloudflare Workers** + KV Storage
- **Google APIs** (Calendar + Gmail)

## 🎨 UI Components

- Mobile-responsive Design
- Touch-optimierte Buttons (44x44px)
- Perfekte Toggle Switches (2:1 Pillenform)
- Barrierefreie Farbkontraste
- Dark Mode Support

## 📦 Installation

```bash
npm install
npm run dev
```

## 🚢 Deployment

### Webflow Cloud
1. Code hochladen
2. Environment Variables setzen
3. Deploy
4. Google Calendar autorisieren

### Cloudflare Workers
```bash
npm run build
wrangler publish
```

## 🔒 Sicherheit

- Passwortgeschütztes Admin Panel
- Rate Limiting (5 req/15min)
- HTTPS-only in Production
- OAuth 2.0 für Google APIs
- Keine PII in Logs

## 📊 Admin Panel

Zugriff: `/secure-admin-panel-xyz789`

### Features:
- ✅ Terminübersicht (Bestätigen/Ablehnen)
- ✅ Timetable (Kalenderansicht)
- ✅ Audit Log (vollständige Historie)
- ✅ System-Einstellungen
- ✅ Google Calendar Status
- ✅ Test-Funktionen (E-Mail, Calendar)

## 📧 E-Mail-System

- **Buchungsbestätigung** an Kunden
- **Admin-Benachrichtigung** bei neuen Anfragen
- **Stornierungsbestätigung**
- **ICS-Kalenderanhänge**
- **UTF-8 & Emoji-Support**
- **Fehlerprotokollierung** im Audit Log

## 🐛 Troubleshooting

### Google Calendar funktioniert nicht
→ Admin Panel → Settings → System-Status prüfen

### E-Mails werden nicht versendet
→ Gmail API aktiviert? OAuth korrekt autorisiert?

### Termine erscheinen nicht
→ Google Calendar neu autorisieren

Weitere Hilfe: **[docs/SETUP.md](docs/SETUP.md)**

## 📝 License

Proprietary - MORO GmbH

## 💬 Support

Bei Fragen oder Problemen: Dokumentation in `docs/` oder Audit Log prüfen.

---

**Version 2.0** - Vollständig optimiert & production-ready 🚀
